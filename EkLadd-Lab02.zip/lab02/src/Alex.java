//package turtles;

import java.awt.Color;
/**
 * A simple example provided for you
 * 
 * 
 */
public class Alex
{
    
    public static void main(String[] args)
    {
        World world = new World();
        Turtle alex = new Turtle(world);
        alex.hide();
        
        System.out.println(alex.getXPos() +", " +alex.getYPos());
        
        alex.moveTo(10, world.getHeight()/2);
        alex.setPenColor(Color.MAGENTA);
        alex.setPenWidth(4);

        int side1 = 100;
        int side2 = 30;
        alex.turn(45);        
        for (int i=0; i<10; i++) {
            alex.forward(side1);
            alex.turn(45);
            alex.forward(side2);
            alex.turn(135);
            alex.forward(side1);
            alex.turn(45);
            alex.forward(side2);
            alex.backward(side2);
            alex.turn(135);
        }
    }
}
